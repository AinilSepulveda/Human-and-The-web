﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controlador_Spawner : MonoBehaviour {

    public GameObject enemy;


    public GameObject spawner1;
    public GameObject spawner2;
    public GameObject spawner3;
    public GameObject spawner4;
    public GameObject spawner5;
    public GameObject spawner6;

    float timeStart = 0f;
    float timeout = 0.5f;

    float maxRandomX = 7;
    float minRandomX = 1;

    float maxRandomY = -21;
    float minRandomY = -14;


    // Use this for initialization
    void Start () {

    }
	
	// Update is called once per frame
	void Update () {


        Vector3 ramdonVector3 = new Vector3(-17.86f, (Random.Range(minRandomY, maxRandomY)), 0f);
        
        timeStart += Time.deltaTime;
        if (timeStart > timeout)
        {
            Instantiate(enemy, ramdonVector3, enemy.transform.rotation);
            timeStart = 0;
        }
        /* Instantiate(enemy, spawner2.transform.position, enemy.transform.rotation);
         Instantiate(enemy, spawner3.transform.position, enemy.transform.rotation);
         Instantiate(enemy, spawner4.transform.position, enemy.transform.rotation);
         Instantiate(enemy, spawner5.transform.position, enemy.transform.rotation);
         Instantiate(enemy, spawner6.transform.position, enemy.transform.rotation);*/


    }
}
