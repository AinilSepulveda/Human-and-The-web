﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Guardi : MonoBehaviour {

    /*public Transform visionDireccion;
      float rangodeVision = 10f;
      int rangodevision = 10;
      Rigidbody2D rb2d;
      bool hola; */
    //    r2

    Transform mytransform;
    bool direccion;
    float timerStart;
    float timerOut = 2;

    // Use this for initialization
    void Start () {
        mytransform = GetComponent<Transform>();

	}

    // Update is called once per frame
    void Update()
    {
        if (direccion)
        {
            mytransform.Translate(Vector2.right * 0.09f);
            timerStart += Time.deltaTime;
        }
        else
        {
            mytransform.Translate(-Vector2.right * 0.09f);
            timerStart += Time.deltaTime;
        }
        Debug.Log(direccion);
        Debug.Log(timerStart);
        /*    RaycastHit2D hit = Physics2D.Raycast(visionDireccion.position, Vector2.right);
        if (hit.collider.gameObject.tag == ("Player"))
        {
            Debug.Log(hola);
        }
	}          */
        /* public bool PuedeVereljugador(out RaycastHit2D hit)
          {
               return Physics2D.Raycast(visionDireccion.transform.position, Vector2.right, out hit, rangodevision) && hit.collider.CompareTag("Player");
         } */
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (direccion ==false && timerStart > timerOut)
        {
            direccion = true;
            timerStart = 0;

        }
        if (direccion == true && timerStart > timerOut)
        {
            direccion = false;
            timerStart = 0;
        }
    }

}
